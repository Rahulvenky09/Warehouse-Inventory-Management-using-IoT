Hello

Warehouse Inventory Management System.

The Following Zip file Contains

1.Final Project Report
2.Final Code of the project.

To read the project report, one should have Acrobat Acrobat Reader 2017 or above.................

To run the project code the following requirements have to be satisfied............

1.Operating System Must be

  Windows - Win 10 and newer, 64 bits
  Linux - 64 bits
  Mac OS X - Version 10.14: "Mojave" or newer, 64 bits

2.Arduino IDE 2.0 (https://www.arduino.cc/en/software/)

3.Boards to install in Arduino IDE
	1.ESP8266(http://arduino.esp8266.com/stable/package_esp8266com_index.json)
	

4.Libraries to install in Arduino IDE

	1.Blynk(1.0.1)(https://docs.blynk.io/en/legacy-platform/what-do-i-need-to-blynk)
	3.ADAFRUIT MQTT(2.5.1)(https://www.arduinolibraries.info/libraries/adafruit-mqtt-library)

Thank You.